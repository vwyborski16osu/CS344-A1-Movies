To compile the program, use the following compilation commands:
gcc -std=gnu99 -Wall -g -o movies movies.c
To run the program with a csv file movies.csv, use ./movies movies.csv